import { Link } from 'react-router-dom';

const Footer = () => {
  return (
  <footer>
      <p>Completed by <Link to='/'>TechyDNA</Link>.</p>
  </footer>
  )
}

export default Footer;